package com.RODS.entity;


public enum RoleType {
    ROLE_ADMIN,
    ROLE_MANAGER,
    ROLE_CUSTOMER
}

// todo make this table in DB