package com.RODS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RodsApplication.class, args);
	}

}
