package com.RODS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RodsApplicationTests {

	@Test
	void contextLoads() {
	}

}
